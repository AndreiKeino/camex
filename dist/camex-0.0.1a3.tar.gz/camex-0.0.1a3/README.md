## Introducing the Camex:

#### Camex stands for "Computational Applied Mathematics EXamples."  
![image](https://andreikeino.github.io/camex/images/user_guide/camex_windows.jpg)

* As it is clear from the name, the program represent a collection of a computational examples.
 
* It has a user - friendly GUI and it can be used by anyone who possess no programming skills.
  
#### Example collection so far...

* The L1 trend filtering.

*  Classical (Markowitz) portfolio optimization.

*  Portfolio optimization 2.


### Please read [the documentation](https://andreikeino.github.io/camex/introduction.html) for more information.
