
main_window_title = 'Camex'
app_name = 'Camex'
app_version = '0.0.1a2'
package_name = 'camex'
user_guide_url = 'https://andreikeino.github.io//camex/user_guide.html'
license_url = 'https://andreikeino.github.io/camex/license.txt'
author = 'Andrei Keino'
